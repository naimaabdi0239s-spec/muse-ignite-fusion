# Hero Video Optimizer

using this repo https://github.com/naimaabdi0239s-spec/muse-ignite-fusion Compress the hero video to under 10 MB (preferably 5–8 MB) while maintaining good visual quality. Save it as public/hero-video.mp4, remove the .asset.json dependency, update the hero section to use /hero-video.mp4, and commit the compressed video to GitHub.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/f3ee9373-9f64-41e0-9041-5224c0ae9dcd).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
